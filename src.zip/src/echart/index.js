import * as echarts from 'echarts'
export default echarts
